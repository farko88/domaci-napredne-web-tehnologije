const express = require("express");
const socket = require("socket.io");


//Inicijalizacija servera
const app = express();
app.set('view engine', 'ejs')
app.engine('html', require('ejs').renderFile);
app.use(express.static('public'))
let server = app.listen(4000, function () {
  console.log("Server je pokrenut");
});

app.get('/rooms/:roomId/join', function(request, response) {
  var roomId = request.params.roomId;
  console.log("soba: ", roomId);
  response.render(__dirname + "/template/index.html", {roomId:roomId});
});

//Nadogradnja servera da prihvati websocket konekcije
let io = socket(server);

//Pokrece se kad se korisnik ucita aplikaciju
io.on("connection", function (socket) {
  console.log("Korisnik konektovan :" + socket.id);

  //Pokrece se kada korisnik unese odgovarajuci broj sobe
  socket.on("join", function (roomName) {
    let rooms = io.sockets.adapter.rooms;
    let room = rooms.get(roomName);

    //TODO: ubaciti proveru da li odgovarajuca soba postoji
    if (room == undefined) {
      socket.join(roomName);
      socket.emit("created");
    } else if (room.size == 1) {
      //room.size == 1 kada je jedna osoba u sobi.
      socket.join(roomName);
      socket.emit("joined");
    } else {
      //kada su oba sagovornika konektovana.
      socket.emit("full");
    }
    console.log(rooms);
  });

  //Pokrece se kada je sagovornik spreman za razgovor.
  socket.on("ready", function (roomName) {
    socket.broadcast.to(roomName).emit("ready"); 
  });

  //Pokrece se kada server dobije icecandidate od konektovanog korisnika.
  socket.on("candidate", function (candidate, roomName) {
    console.log(candidate);
    socket.broadcast.to(roomName).emit("candidate", candidate); //Salje Candidate drugom ucesniku.
  });

  //Pokrece se kada server dobije offer.
  socket.on("offer", function (offer, roomName) {
    socket.broadcast.to(roomName).emit("offer", offer); //Salje Offer drugom korisniku.
  });

  //Pokrece se kada server dobije answer
  socket.on("answer", function (answer, roomName) {
    socket.broadcast.to(roomName).emit("answer", answer); //Salje Answer drugom korisniku.
  });

  //Pokrece se kada korisnik napusti sobu
  socket.on("leave", function (roomName) {
    socket.leave(roomName);
    socket.broadcast.to(roomName).emit("leave");
  });
});
