Pokrenuti `yarn install`
zatim `node index.js`

otvoriti u browser-u http://localhost:4000/rooms/12312312312/join gde je 12312312312 broj sobe, koristiti id po zelji, da bi se dobila unikatna soba


Ovaj projekat je primer koriscenja webrtc-a za usmeno polaganje ispita na daljinu. 
Moguce nadogradnje projekta: 
  * Zakazivanje poziva, slanje pozivnica na email profesora i ucenika
  * Authentikacija ucesnika, generisanje unikatnog tokena za svakog ucesnika
  * Screenshare