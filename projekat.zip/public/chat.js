let socket = io();
let divVideoChat = document.getElementById("video-chat-room");
let joinButton = document.getElementById("join");
let userVideo = document.getElementById("user-video");
let peerVideo = document.getElementById("peer-video");
let roomName = document.getElementById("roomId");
let creator = false;
let rtcPeerConnection;
let userStream;

let divButtonGroup = document.getElementById("btn-group");
let muteButton = document.getElementById("muteButton");
let hideCameraButton = document.getElementById("hideCameraButton");
let leaveRoomButton = document.getElementById("leaveRoomButton");

let muteFlag = false;
let hideCameraFlag = false;

// lista stun server URL-ova.
let iceServers = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun.services.mozilla.com" },
  ],
};

muteButton.addEventListener("click", function () {
  muteFlag = !muteFlag;
  if (muteFlag) {
    userStream.getTracks()[0].enabled = false;
    muteButton.textContent = "Uključi mikrofon";
  } else {
    userStream.getTracks()[0].enabled = true;
    muteButton.textContent = "Ugasi mikrofon";
  }
});

hideCameraButton.addEventListener("click", function () {
  hideCameraFlag = !hideCameraFlag;
  if (hideCameraFlag) {
    userStream.getTracks()[1].enabled = false;
    hideCameraButton.textContent = "Prikaži kameru";
  } else {
    userStream.getTracks()[1].enabled = true;
    hideCameraButton.textContent = "Ugasi kameru";
  }
});

leaveRoomButton.addEventListener("click", function () {
  socket.emit("leave", roomName); //Slanje leave komande serveru

  divButtonGroup.style = "display:none";

  //Stopiranje medija
  if (userVideo.srcObject) {
    userVideo.srcObject.getTracks()[0].stop(); 
    userVideo.srcObject.getTracks()[1].stop(); 
  }
  if (peerVideo.srcObject) {
    peerVideo.srcObject.getTracks()[0].stop(); 
    peerVideo.srcObject.getTracks()[1].stop(); 
  }

  //Zatvaranje rtc peer konekcije
  if (rtcPeerConnection) {
    rtcPeerConnection.ontrack = null;
    rtcPeerConnection.onicecandidate = null;
    rtcPeerConnection.close();
    rtcPeerConnection = null;
  }
});

//pokrece se kada se soba napravi
socket.on("created", function () {
  creator = true;

  navigator.mediaDevices
    .getUserMedia({
      audio: true,
      video: { width: 500, height: 500 },
    })
    .then(function (stream) {
      userStream = stream;
      divButtonGroup.style = "display:flex";
      userVideo.srcObject = stream;
      userVideo.onloadedmetadata = function (e) {
        userVideo.play();
      };
    })
    .catch(function (err) {
      console.log(err);
      alert("Ne moze se pristupiti kameri/mikrofonu!");
    });
});

// Pokrece se kada se korisnik konektuje
socket.on("joined", function () {
  creator = false;

  navigator.mediaDevices
    .getUserMedia({
      audio: true,
      video: { width: 500, height: 500 },
    })
    .then(function (stream) {
      userStream = stream;
      divButtonGroup.style = "display:flex";
      userVideo.srcObject = stream;
      userVideo.onloadedmetadata = function (e) {
        userVideo.play();
      };
      socket.emit("ready", roomName);
    })
    .catch(function (err) {
      console.log(err);
      alert("Ne moze se pristupiti kameri/mikrofonu!");
    });
});


//Pokrece se kada je soba puna.
socket.on("full", function () {
  alert("Soba je puna!");
});

//Pokrece se kada se korisnik konektuje i spreman je za razgovor
socket.on("ready", function () {
  if (creator) {
    rtcPeerConnection = new RTCPeerConnection(iceServers);
    rtcPeerConnection.onicecandidate = OnIceCandidateFunction;
    rtcPeerConnection.ontrack = OnTrackFunction;
    rtcPeerConnection.addTrack(userStream.getTracks()[0], userStream);
    rtcPeerConnection.addTrack(userStream.getTracks()[1], userStream);


    rtcPeerConnection
      .createOffer()
      .then((offer) => {
        rtcPeerConnection.setLocalDescription(offer);
        socket.emit("offer", offer, roomName);
      })

      .catch((error) => {
        console.log(error);
      });
  }
});

// Pokrece se kada se dobije icecandidate od ucesnika
socket.on("candidate", function (candidate) {
  let icecandidate = new RTCIceCandidate(candidate);
  rtcPeerConnection.addIceCandidate(icecandidate);
});

// Pokrece se na prijem offer-a
socket.on("offer", function (offer) {
  if (!creator) {
    rtcPeerConnection = new RTCPeerConnection(iceServers);
    rtcPeerConnection.onicecandidate = OnIceCandidateFunction;
    rtcPeerConnection.ontrack = OnTrackFunction;
    rtcPeerConnection.addTrack(userStream.getTracks()[0], userStream);
    rtcPeerConnection.addTrack(userStream.getTracks()[1], userStream);
    rtcPeerConnection.setRemoteDescription(offer);

    rtcPeerConnection
      .createAnswer()
      .then((answer) => {
        rtcPeerConnection.setLocalDescription(answer);
        socket.emit("answer", answer, roomName);
      })
      .catch((error) => {
        console.log(error);
      });
  }
});

//Pokrece se na prijem odgovora od drugog ucesnika.
socket.on("answer", function (answer) {
  rtcPeerConnection.setRemoteDescription(answer);
});

// Pokrece se kada jedan od korisnika napusti sobu
socket.on("leave", function () {
  creator = true; 

  //stopiranje medije
  if (peerVideo.srcObject) {
    peerVideo.srcObject.getTracks()[0].stop(); 
    peerVideo.srcObject.getTracks()[1].stop(); 
  }

  //Zatvaranje rtc peer konekcije
  if (rtcPeerConnection) {
    rtcPeerConnection.ontrack = null;
    rtcPeerConnection.onicecandidate = null;
    rtcPeerConnection.close();
    rtcPeerConnection = null;
  }
});

// Implementacija handlera za ice candidate.
function OnIceCandidateFunction(event) {
  console.log("Candidate");
  if (event.candidate) {
    socket.emit("candidate", event.candidate, roomName);
  }
}

function OnTrackFunction(event) {
  peerVideo.srcObject = event.streams[0];
  peerVideo.onloadedmetadata = function (e) {
    peerVideo.play();
  };
}

if (roomName.value == "") {
  alert("Soba ne postoji!");
} else {
  socket.emit("join", roomName.value);
}